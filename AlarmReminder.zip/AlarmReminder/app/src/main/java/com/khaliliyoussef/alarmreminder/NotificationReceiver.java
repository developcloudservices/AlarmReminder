package com.khaliliyoussef.alarmreminder;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.khaliliyoussef.alarmreminder.model.User;

import static com.khaliliyoussef.alarmreminder.reminder.ReminderAlarmService.NO_ACTION;
import static com.khaliliyoussef.alarmreminder.reminder.ReminderAlarmService.YES_ACTION;

/**
 * Created by Khalil on 11/1/2017.
 */

public class NotificationReceiver extends BroadcastReceiver {
    private static final String TAG =NotificationReceiver.class.getSimpleName() ;
    private FirebaseAuth mAuth = FirebaseAuth.getInstance();
    DatabaseReference noty;

    Button alarmYesbtn;
    Button alarmNobtn;
    String userId;
    Boolean notify = false;
    User user;
    private String followerId="";

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (YES_ACTION.equals(action)) {
            Toast.makeText(context, "YES CALLED Do Nothing >_< " ,Toast.LENGTH_SHORT).show();
            //get user ID
            //go to notify
            //make it false

        } else if (NO_ACTION.equals(action)) {
             Toast.makeText(context, "NO CALLED notifying your followers ..", Toast.LENGTH_SHORT).show();
            //user haven't taken the medication
            //get follower id
            userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
            Log.i(TAG, "onCheckCurrentUserStatus: "+userId);
            //make notify = true
            getFollowerId(userId);
            //check it's not empty
            if (followerId==null||followerId.trim().length()==0)
            {
                Toast.makeText(context, "notifying the user", Toast.LENGTH_SHORT).show();
                DatabaseReference followerRef;
                followerRef = FirebaseDatabase.getInstance().getReference().child("users").child(followerId).child("notify");
                followerRef.setValue(true);
            }


        } else {
            Toast.makeText(context, "else block", Toast.LENGTH_SHORT).show();
        }

    }


    private void getFollowerId(String userId)
    {

        DatabaseReference currentUserRef = FirebaseDatabase.getInstance().getReference().child("users").child(userId);
        currentUserRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                user = dataSnapshot.getValue(User.class);

                if (user!=null) {
                   if(followerId==null||followerId.trim().length()==0) {
                       followerId=user.getFollowerId();
                       Log.d(TAG, "onDataChange: "+followerId);
                   }
                    }

                }



            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.d(TAG, "onCancelled: "+databaseError.getMessage());

            }
        });

    }



}
