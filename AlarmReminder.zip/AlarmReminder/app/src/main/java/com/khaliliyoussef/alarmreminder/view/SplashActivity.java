package com.khaliliyoussef.alarmreminder.view;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import com.khaliliyoussef.alarmreminder.R;


public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        ImageView splashLogo = (ImageView) findViewById(R.id.splash_logo);
        android.view.animation.Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.clockwise);
        splashLogo.setAnimation(animation);

        animation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

                Snackbar.make(findViewById(R.id.splash_layout), "MedAlarm", Snackbar.LENGTH_SHORT).show();
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                finish();
                Intent Go = new Intent(getApplicationContext(), StartActivity.class);
                startActivity(Go);

            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
    }


}


