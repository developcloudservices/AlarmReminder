package com.khaliliyoussef.alarmreminder.view;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.khaliliyoussef.alarmreminder.R;
import com.khaliliyoussef.alarmreminder.customfonts.MyEditText;
import com.khaliliyoussef.alarmreminder.customfonts.MyTextView;
import com.khaliliyoussef.alarmreminder.model.User;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class RegisterActivity extends AppCompatActivity {
    private static final String TAG = "RegisterActivity";
    MyEditText user;
    MyEditText pass;
    MyEditText email;
    MyEditText mob;
    MyTextView login;
    MyTextView signup;
    ProgressBar mProgressBar;
    FirebaseAuth mAuth = FirebaseAuth.getInstance();
    DatabaseReference usersRef;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        user = (MyEditText) findViewById(R.id.user);
        pass = (MyEditText) findViewById(R.id.pass);
        email = (MyEditText) findViewById(R.id.email);
        mob = (MyEditText) findViewById(R.id.mob);
        signup = (MyTextView) findViewById(R.id.signup);
        login = (MyTextView) findViewById(R.id.login);
        mProgressBar = (ProgressBar) findViewById(R.id.progressBar);


        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent it = new Intent(RegisterActivity.this, LoginActivity.class);
                startActivity(it);

            }
        });
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String userName = user.getText().toString().trim();
                String password = pass.getText().toString().trim();
                String eMail = email.getText().toString().trim();
                long mobileNumber = Long.parseLong(mob.getEditableText().toString().trim());
                onAddNewUser(eMail, password, userName, mobileNumber);

                // mAuth.signInWithEmailAndPassword(eMail, password);
            }
        });

    }

    private boolean onAddNewUser(final String eMail, String password, final String userName, final long mobileNumber) {
        // User user = new User(userName, email, password, mobileNumber);

        onShowProgressBar();
        mAuth.createUserWithEmailAndPassword(eMail, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        Log.d(TAG, "createUserWithEmail:onComplete:" + task.isSuccessful());

                        // If sign in fails, display a message to the user. If sign in succeeds
                        // the auth state listener will be notified and logic to handle the
                        // signed in user can be handled in the listener.
                        if (task.isSuccessful()) {
                            User user=new User(userName,false,"",mobileNumber);
                            usersRef = FirebaseDatabase.getInstance().getReference("users").child(mAuth.getCurrentUser().getUid());
                            usersRef.setValue(user);
                            Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(intent);
                            finish();


                        }
                        if (!task.isSuccessful()) {
                            Log.d(TAG, "onComplete: Failed=" + task.getException().getMessage()); //ADD THIS

                            Toast.makeText(RegisterActivity.this, "Failed " + task.getException().getMessage(),
                                    Toast.LENGTH_SHORT).show();
                            onHideProgressBar();

                        }


                    }
                });
        return true;
    }

    public void onShowProgressBar() {
        mProgressBar.setVisibility(View.VISIBLE);
//        getWindow().setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
//                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
    }

    public void onHideProgressBar() {
        mProgressBar.setVisibility(View.GONE);
//        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
    }
}
