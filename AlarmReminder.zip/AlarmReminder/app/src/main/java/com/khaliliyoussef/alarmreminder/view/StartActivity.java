package com.khaliliyoussef.alarmreminder.view;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import com.khaliliyoussef.alarmreminder.R;


public class StartActivity extends AppCompatActivity {

    Button startLoginButton;
    Button startRegisterButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);
        isFirstTime();
        startLoginButton = (Button) findViewById(R.id.start_login_btn);
        startLoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent loginIntent = new Intent(StartActivity.this, LoginActivity.class);
                startActivity(loginIntent);

            }
        });
        startRegisterButton = (Button) findViewById(R.id.start_register_btn);
        startRegisterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent registerIntent = new Intent(StartActivity.this, RegisterActivity.class);
                startActivity(registerIntent);

            }
        });
    }

    //check to see if it's the first time to launch this app
    //yes -->goes to splash screen
    public void isFirstTime() {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        if (!prefs.getBoolean("first_time", false)) {
            Intent i = new Intent(StartActivity.this, SplashActivity.class);
            prefs.edit().putBoolean("first_time", true).apply();
            this.startActivity(i);
            this.finish();
        }
    }
}
