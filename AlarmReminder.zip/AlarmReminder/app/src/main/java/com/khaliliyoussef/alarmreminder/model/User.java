package com.khaliliyoussef.alarmreminder.model;

/**
 * Created by Khalil on 10/22/2017.
 * note that var name should be identical to the vars on the firebase server
 */

public class User {
    private String name;
    private boolean notify;
    private String followerId;
    private long mobileNumber;


    public User() {
    }

    public User(String name, boolean notify, String followerID, long mobileNumber) {
        this.name = name;
        this.notify = notify;
        this.followerId = followerID;
        this.mobileNumber = mobileNumber;

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public boolean isNotify() {
        return notify;
    }

    public void setNotify(boolean notify) {
        this.notify = notify;
    }

    public String getFollowerId() {
        return followerId;
    }

    public void setFollowerId(String followerId) {
        this.followerId = followerId;
    }

    public long getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(long mobileNumber) {
        this.mobileNumber = mobileNumber;
    }


}