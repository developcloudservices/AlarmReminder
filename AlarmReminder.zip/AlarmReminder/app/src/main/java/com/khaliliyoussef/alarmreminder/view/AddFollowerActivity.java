package com.khaliliyoussef.alarmreminder.view;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.khaliliyoussef.alarmreminder.R;
import com.khaliliyoussef.alarmreminder.model.User;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class AddFollowerActivity extends AppCompatActivity {
    Button searchButton;
    EditText editText;
    Button addButton;
    String followerId="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_follower);

        searchButton = (Button) findViewById(R.id.addFollower_search_btn);
        addButton = (Button) findViewById(R.id.addFollower_add_btn);
        editText = (EditText) findViewById(R.id.addFollower_add_ed);
        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Long mobileNumber= Long.parseLong(editText.getText().toString());
                Query userRef = FirebaseDatabase.getInstance().getReference().child("users").orderByChild("mobileNumber").equalTo(mobileNumber);
                userRef. addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {

                        for (DataSnapshot postSnapshot : dataSnapshot.getChildren())
                        {
                            User user = postSnapshot.getValue(User.class);
                            if (user!=null)
                            {

                                Toast.makeText(AddFollowerActivity.this, "found User :"+postSnapshot.getKey(), Toast.LENGTH_SHORT).show();
                                addButton.setVisibility(View.VISIBLE);
                                followerId=postSnapshot.getKey();
                            }


                        }

                        }


                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        Toast.makeText(AddFollowerActivity.this, ""+databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                        addButton.setVisibility(View.INVISIBLE);

                    }
                });
                Toast.makeText(AddFollowerActivity.this, "not found", Toast.LENGTH_SHORT).show();
                addButton.setVisibility(View.GONE);
            }
        });
addButton.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {

FirebaseDatabase.getInstance().getReference().child("users").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("followerId").setValue(followerId);
    }
});

    }
}
